package com.example.hetvi_vaghela_assignement_1_emicalcapp

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Get UI references
        val etLoanAmount: EditText = findViewById(R.id.etLoanAmount)
        val etInterestRate: EditText = findViewById(R.id.etInterestRate)
        val etWorkLoadPeriod: EditText = findViewById(R.id.etTenure) // Updated to work load period
        val btnCalculate: Button = findViewById(R.id.btnCalculate)
        val tvResult: TextView = findViewById(R.id.tvResult)

        // Calculate EMI on button click
        btnCalculate.setOnClickListener {
            val loanAmount = etLoanAmount.text.toString().toDoubleOrNull()
            val interestRate = etInterestRate.text.toString().toDoubleOrNull()
            val workLoadPeriod = etWorkLoadPeriod.text.toString().toIntOrNull()

            if (loanAmount != null && interestRate != null && workLoadPeriod != null) {
                // EMI calculation logic
                val paymentsPerYear = 12
                val interestRatePerPeriod = interestRate / paymentsPerYear / 100
                val totalPayments = workLoadPeriod * paymentsPerYear

                val emi = (loanAmount * interestRatePerPeriod * Math.pow(1 + interestRatePerPeriod, totalPayments.toDouble())) /
                        (Math.pow(1 + interestRatePerPeriod, totalPayments.toDouble()) - 1)

                // Display result
                tvResult.text = getString(R.string.monthly_emi) + String.format("%.2f", emi)
            } else {
                // Handle invalid input
                tvResult.text = getString(R.string.invalid_input_message)
            }
        }
    }
}
